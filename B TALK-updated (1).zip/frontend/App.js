import React, { useEffect, useState } from 'react';
import { SafeAreaView } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import LoginScreen from './screens/LoginScreen';
import FeedScreen from './screens/FeedScreen';
export const API_BASE = 'http://10.0.2.2:4000/api';
export default function App(){ const [authed, setAuthed] = useState(false); useEffect(()=>{ SecureStore.getItemAsync('accessToken').then(t=>setAuthed(!!t)); },[]); return (<SafeAreaView style={{flex:1}}>{authed ? <FeedScreen onLogout={()=>{SecureStore.deleteItemAsync('accessToken'); setAuthed(false);}} /> : <LoginScreen onLogin={()=>setAuthed(true)} />}</SafeAreaView>); }